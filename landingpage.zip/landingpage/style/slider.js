var splide = new Splide( '.splide', {
    type    : 'loop',
    perPage : 1,
    autoplay: true,
  } );
  
  splide.mount();